function [c,f,s] = pdefun(x,t,u,dudx)
c = 1./myfun1(x);
f = dudx;
s = 0;
end