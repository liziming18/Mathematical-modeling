function u0 = icfun(x)
u0 = 37;
end