function [pL,qL,pR,qR] = bcfun(xL,uL,xR,uR,t)
pL = uL - timefunc(t);
qL = 0;
pR = uR - 75;
qR = 0;
end