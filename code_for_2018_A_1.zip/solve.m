L = 0.1;
x = 0.1:0.1:15.3;
t = 0:1:5400;
m = 1;
sol = pdepe(m,@pdefun,@icfun,@bcfun,x,t);